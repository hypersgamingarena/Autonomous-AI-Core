// Add animation classes to elements when they come into view
document.addEventListener('DOMContentLoaded', function() {
    const animateOnScroll = () => {
        const elements = document.querySelectorAll('.card, .dashboard-card, .btn');
        elements.forEach(element => {
            const elementTop = element.getBoundingClientRect().top;
            const elementBottom = element.getBoundingClientRect().bottom;
            
            if (elementTop < window.innerHeight && elementBottom > 0) {
                element.classList.add('animate-fade-in');
            }
        });
    };

    // Initial check
    animateOnScroll();

    // Check on scroll
    window.addEventListener('scroll', animateOnScroll);
});

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Form validation with animation and error handling
const forms = document.querySelectorAll('form');
forms.forEach(form => {
    form.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        if (!this.checkValidity()) {
            e.stopPropagation();
            
            // Add shake animation to invalid fields
            const invalidFields = this.querySelectorAll(':invalid');
            invalidFields.forEach(field => {
                field.classList.add('animate-shake');
                setTimeout(() => {
                    field.classList.remove('animate-shake');
                }, 500);
            });
            
            this.classList.add('was-validated');
            return;
        }

        try {
            showLoading();
            const formData = new FormData(this);
            const data = Object.fromEntries(formData.entries());
            
            const response = await makeApiCall(this.action, this.method, data);
            
            if (response.success) {
                showToast('Operation completed successfully', 'success');
                if (response.redirectUrl) {
                    window.location.href = response.redirectUrl;
                }
            } else {
                showToast(response.message || 'Operation failed', 'error');
            }
        } catch (error) {
            showToast('An error occurred. Please try again.', 'error');
            console.error('Form submission error:', error);
        } finally {
            hideLoading();
        }
    });
});

// Code editor with error handling
const codeEditor = document.querySelector('.code-editor');
if (codeEditor) {
    try {
        const editor = CodeMirror.fromTextArea(codeEditor, {
            mode: 'text/x-csharp',
            theme: 'monokai',
            lineNumbers: true,
            autoCloseBrackets: true,
            matchBrackets: true,
            indentUnit: 4,
            tabSize: 4,
            lineWrapping: true,
            extraKeys: {
                "Ctrl-Space": "autocomplete"
            }
        });

        // Add error handling for editor
        editor.on('change', function() {
            try {
                // Your code validation logic here
            } catch (error) {
                console.error('Code editor error:', error);
                showToast('Error in code editor', 'error');
            }
        });
    } catch (error) {
        console.error('Failed to initialize code editor:', error);
        showToast('Failed to initialize code editor', 'error');
    }
}

// Dashboard charts with error handling
const charts = document.querySelectorAll('canvas');
charts.forEach(chart => {
    try {
        const ctx = chart.getContext('2d');
        const gradient = ctx.createLinearGradient(0, 0, 0, 400);
        gradient.addColorStop(0, 'rgba(52, 152, 219, 0.8)');
        gradient.addColorStop(1, 'rgba(52, 152, 219, 0.1)');
        
        new Chart(ctx, {
            type: 'line',
            data: {
                // Your chart data here
            },
            options: {
                animation: {
                    duration: 2000,
                    easing: 'easeInOutQuart'
                },
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                    }
                }
            }
        });
    } catch (error) {
        console.error('Chart initialization error:', error);
        showToast('Failed to initialize chart', 'error');
    }
});

// Loading spinner with timeout
function showLoading() {
    const spinner = document.createElement('div');
    spinner.className = 'spinner';
    document.body.appendChild(spinner);
    
    // Add timeout to prevent infinite loading
    setTimeout(() => {
        if (document.body.contains(spinner)) {
            spinner.remove();
            showToast('Operation timed out', 'error');
        }
    }, 30000); // 30 seconds timeout
}

function hideLoading() {
    const spinner = document.querySelector('.spinner');
    if (spinner) {
        spinner.remove();
    }
}

// API calls with retry logic and better error handling
async function makeApiCall(url, method = 'GET', data = null, retryCount = 3) {
    showLoading();
    let lastError;
    
    for (let i = 0; i < retryCount; i++) {
        try {
            const response = await fetch(url, {
                method,
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('authToken')}`
                },
                body: data ? JSON.stringify(data) : null
            });
            
            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            lastError = error;
            console.error(`API call attempt ${i + 1} failed:`, error);
            
            if (i < retryCount - 1) {
                // Wait before retrying (exponential backoff)
                await new Promise(resolve => setTimeout(resolve, Math.pow(2, i) * 1000));
                continue;
            }
        }
    }
    
    throw lastError;
}

// Enhanced toast notifications
function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type} animate-fade-in`;
    
    // Add icon based on type
    const icon = type === 'success' ? '✓' : '✕';
    toast.innerHTML = `<span class="toast-icon">${icon}</span> ${message}`;
    
    document.body.appendChild(toast);
    
    // Auto-dismiss after 3 seconds
    setTimeout(() => {
        toast.classList.add('animate-fade-out');
        setTimeout(() => toast.remove(), 500);
    }, 3000);
}

// Add shake animation to CSS
const style = document.createElement('style');
style.textContent = `
    @keyframes shake {
        0%, 100% { transform: translateX(0); }
        25% { transform: translateX(-5px); }
        75% { transform: translateX(5px); }
    }
    
    .animate-shake {
        animation: shake 0.5s ease-in-out;
    }
    
    .toast {
        position: fixed;
        bottom: 20px;
        right: 20px;
        padding: 1rem 2rem;
        border-radius: 5px;
        color: white;
        z-index: 1000;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    
    .toast-icon {
        font-size: 1.2rem;
    }
    
    .toast-success {
        background-color: #2ecc71;
    }
    
    .toast-error {
        background-color: #e74c3c;
    }
    
    .animate-fade-out {
        animation: fadeOut 0.5s ease-out forwards;
    }
    
    @keyframes fadeOut {
        from { opacity: 1; }
        to { opacity: 0; }
    }
    
    .spinner {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        z-index: 1000;
    }
`;
document.head.appendChild(style); 