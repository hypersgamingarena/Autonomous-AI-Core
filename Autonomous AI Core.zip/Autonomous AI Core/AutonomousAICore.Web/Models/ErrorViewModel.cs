namespace AutonomousAICore.Web.Models
{
    public class ErrorViewModel
    {
        public int? StatusCode { get; set; }
        public string Message { get; set; }
        public string RequestId { get; set; }
        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
        public bool ShowHomeButton { get; set; } = true;
        public string ReturnUrl { get; set; }
    }
} 