using System;
using System.Collections.Generic;

namespace AutonomousAICore.API.ViewModels.Dashboard
{
    public class DashboardViewModel
    {
        public DashboardStats Stats { get; set; }
        public List<RecentActivity> RecentActivities { get; set; }
        public List<ModelPerformance> ModelPerformances { get; set; }
        public SystemHealth Health { get; set; }
        public List<Alert> Alerts { get; set; }
    }

    public class DashboardStats
    {
        public int TotalModels { get; set; }
        public int ActiveModels { get; set; }
        public int PendingTraining { get; set; }
        public int FailedModels { get; set; }
        public double AverageAccuracy { get; set; }
        public int TotalDatasets { get; set; }
        public int ActiveUsers { get; set; }
        public int TotalTrainingHours { get; set; }
    }

    public class RecentActivity
    {
        public string Id { get; set; }
        public string Type { get; set; }
        public string Description { get; set; }
        public DateTime Timestamp { get; set; }
        public string User { get; set; }
        public string Status { get; set; }
    }

    public class ModelPerformance
    {
        public string ModelId { get; set; }
        public string ModelName { get; set; }
        public double Accuracy { get; set; }
        public double Precision { get; set; }
        public double Recall { get; set; }
        public double F1Score { get; set; }
        public DateTime LastEvaluated { get; set; }
    }

    public class SystemHealth
    {
        public double CpuUsage { get; set; }
        public double MemoryUsage { get; set; }
        public double DiskSpace { get; set; }
        public bool DatabaseConnection { get; set; }
        public bool AIServiceStatus { get; set; }
        public List<string> ActiveServices { get; set; }
    }

    public class Alert
    {
        public string Id { get; set; }
        public string Type { get; set; }
        public string Message { get; set; }
        public string Severity { get; set; }
        public DateTime CreatedAt { get; set; }
        public bool IsResolved { get; set; }
    }
} 