using AutonomousAICore.API.AI;
using AutonomousAICore.API.Database;
using AutonomousAICore.API.Admin;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System.IO;
using AutonomousAICore.API.Tenant;
using AutonomousAICore.API.Middleware;
using Microsoft.EntityFrameworkCore;
using AutonomousAICore.API.Services;
using AutonomousAICore.API.Services.Interfaces;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container
builder.Services.AddControllers();

// Configure database
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Register services
builder.Services.AddScoped<IAIService, AIService>();

// Add CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll",
        builder =>
        {
            builder.AllowAnyOrigin()
                   .AllowAnyMethod()
                   .AllowAnyHeader();
        });
});

// Add Swagger
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Configure logging
builder.Logging.ClearProviders();
builder.Logging.AddConsole();
builder.Logging.AddDebug();

// Configure paths
var dataPath = Path.Combine(builder.Environment.ContentRootPath, "Data");
var modelPath = Path.Combine(dataPath, "Models");
var dbPath = Path.Combine(dataPath, "Database", "autonomous.db");

// Ensure directories exist
Directory.CreateDirectory(dataPath);
Directory.CreateDirectory(modelPath);
Directory.CreateDirectory(Path.GetDirectoryName(dbPath));

// Register services
builder.Services.AddSingleton(new DatabaseService(dbPath));
builder.Services.AddScoped<CrudService>();
builder.Services.AddScoped<AdminConfigService>();
builder.Services.AddScoped<LogService>();
builder.Services.AddSingleton(new AIWorkflow(dataPath, modelPath));

// Register tenant services
builder.Services.AddSingleton<TenantService>();

var app = builder.Build();

// Configure the HTTP request pipeline
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseCors("AllowAll");
app.UseAuthorization();

// Add tenant middleware
app.UseTenantMiddleware();

app.MapControllers();

// Ensure database is created
using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    try
    {
        var context = services.GetRequiredService<ApplicationDbContext>();
        context.Database.EnsureCreated();
    }
    catch (Exception ex)
    {
        var logger = services.GetRequiredService<ILogger<Program>>();
        logger.LogError(ex, "An error occurred while creating the database.");
    }
}

app.Run();
