using System;
using System.Collections.Generic;
using System.Data;
using AutonomousAICore.API.Database;

namespace AutonomousAICore.API.Tenant
{
    public class Tenant
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Identifier { get; set; }
        public Dictionary<string, object> Settings { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? LastModified { get; set; }
    }

    public class TenantService
    {
        private readonly CrudService _crudService;
        private const string TENANTS_TABLE = "Tenants";
        private const string TENANT_SETTINGS_TABLE = "TenantSettings";

        public TenantService(CrudService crudService)
        {
            _crudService = crudService;
            InitializeTenantTables();
        }

        private void InitializeTenantTables()
        {
            // Create Tenants table
            var tenantsQuery = $@"
                CREATE TABLE IF NOT EXISTS {TENANTS_TABLE} (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Name TEXT NOT NULL,
                    Identifier TEXT UNIQUE NOT NULL,
                    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
                    LastModified DATETIME
                );";

            // Create TenantSettings table
            var settingsQuery = $@"
                CREATE TABLE IF NOT EXISTS {TENANT_SETTINGS_TABLE} (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    TenantId INTEGER NOT NULL,
                    Key TEXT NOT NULL,
                    Value TEXT NOT NULL,
                    LastModified DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (TenantId) REFERENCES {TENANTS_TABLE}(Id),
                    UNIQUE(TenantId, Key)
                );";

            _crudService.ExecuteNonQuery(tenantsQuery);
            _crudService.ExecuteNonQuery(settingsQuery);
        }

        public Tenant CreateTenant(string name, string identifier)
        {
            var values = new Dictionary<string, object>
            {
                { "Name", name },
                { "Identifier", identifier }
            };

            var id = _crudService.Insert(TENANTS_TABLE, values);
            return new Tenant
            {
                Id = (int)id,
                Name = name,
                Identifier = identifier,
                Settings = new Dictionary<string, object>(),
                CreatedAt = DateTime.UtcNow
            };
        }

        public Tenant GetTenant(string identifier)
        {
            var parameters = new Dictionary<string, object>
            {
                { "@identifier", identifier }
            };

            var query = $"SELECT * FROM {TENANTS_TABLE} WHERE Identifier = @identifier;";
            var result = _crudService.ExecuteQuery(query, parameters);

            if (result.Rows.Count == 0)
            {
                return null;
            }

            var row = result.Rows[0];
            var tenant = new Tenant
            {
                Id = Convert.ToInt32(row["Id"]),
                Name = row["Name"].ToString(),
                Identifier = row["Identifier"].ToString(),
                CreatedAt = Convert.ToDateTime(row["CreatedAt"]),
                LastModified = row["LastModified"] != DBNull.Value ? Convert.ToDateTime(row["LastModified"]) : null,
                Settings = LoadTenantSettings(Convert.ToInt32(row["Id"]))
            };

            return tenant;
        }

        public void UpdateTenantSettings(int tenantId, Dictionary<string, object> settings)
        {
            foreach (var setting in settings)
            {
                var values = new Dictionary<string, object>
                {
                    { "TenantId", tenantId },
                    { "Key", setting.Key },
                    { "Value", System.Text.Json.JsonSerializer.Serialize(setting.Value) }
                };

                var query = $@"
                    INSERT INTO {TENANT_SETTINGS_TABLE} (TenantId, Key, Value)
                    VALUES (@TenantId, @Key, @Value)
                    ON CONFLICT(TenantId, Key) DO UPDATE SET
                        Value = @Value,
                        LastModified = CURRENT_TIMESTAMP;";

                _crudService.ExecuteNonQuery(query, values);
            }

            // Update tenant's LastModified
            var updateQuery = $"UPDATE {TENANTS_TABLE} SET LastModified = CURRENT_TIMESTAMP WHERE Id = @Id;";
            _crudService.ExecuteNonQuery(updateQuery, new Dictionary<string, object> { { "@Id", tenantId } });
        }

        private Dictionary<string, object> LoadTenantSettings(int tenantId)
        {
            var parameters = new Dictionary<string, object>
            {
                { "@tenantId", tenantId }
            };

            var query = $"SELECT Key, Value FROM {TENANT_SETTINGS_TABLE} WHERE TenantId = @tenantId;";
            var result = _crudService.ExecuteQuery(query, parameters);

            var settings = new Dictionary<string, object>();
            foreach (DataRow row in result.Rows)
            {
                var key = row["Key"].ToString();
                var value = System.Text.Json.JsonSerializer.Deserialize<object>(row["Value"].ToString());
                settings[key] = value;
            }

            return settings;
        }

        public List<Tenant> GetAllTenants()
        {
            var query = $"SELECT * FROM {TENANTS_TABLE};";
            var result = _crudService.ExecuteQuery(query);

            var tenants = new List<Tenant>();
            foreach (DataRow row in result.Rows)
            {
                var tenant = new Tenant
                {
                    Id = Convert.ToInt32(row["Id"]),
                    Name = row["Name"].ToString(),
                    Identifier = row["Identifier"].ToString(),
                    CreatedAt = Convert.ToDateTime(row["CreatedAt"]),
                    LastModified = row["LastModified"] != DBNull.Value ? Convert.ToDateTime(row["LastModified"]) : null,
                    Settings = LoadTenantSettings(Convert.ToInt32(row["Id"]))
                };
                tenants.Add(tenant);
            }

            return tenants;
        }

        public void DeleteTenant(int tenantId)
        {
            // Delete tenant settings first
            var deleteSettingsQuery = $"DELETE FROM {TENANT_SETTINGS_TABLE} WHERE TenantId = @tenantId;";
            _crudService.ExecuteNonQuery(deleteSettingsQuery, new Dictionary<string, object> { { "@tenantId", tenantId } });

            // Delete tenant
            var deleteTenantQuery = $"DELETE FROM {TENANTS_TABLE} WHERE Id = @tenantId;";
            _crudService.ExecuteNonQuery(deleteTenantQuery, new Dictionary<string, object> { { "@tenantId", tenantId } });
        }
    }
} 