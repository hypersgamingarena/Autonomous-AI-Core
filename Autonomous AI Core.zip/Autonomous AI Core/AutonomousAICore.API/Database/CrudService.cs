using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.Sqlite;

namespace AutonomousAICore.API.Database
{
    public class CrudService
    {
        private readonly DatabaseService _dbService;

        public CrudService(DatabaseService dbService)
        {
            _dbService = dbService ?? throw new ArgumentNullException(nameof(dbService));
        }

        public DataTable ExecuteQuery(string query, Dictionary<string, object> parameters = null)
        {
            using (var connection = _dbService.GetConnection())
            using (var command = connection.CreateCommand())
            {
                command.CommandText = query;

                if (parameters != null)
                {
                    foreach (var param in parameters)
                    {
                        command.Parameters.AddWithValue(param.Key, param.Value);
                    }
                }

                var dataTable = new DataTable();
                using (var reader = command.ExecuteReader())
                {
                    dataTable.Load(reader);
                }

                return dataTable;
            }
        }

        public int ExecuteNonQuery(string query, Dictionary<string, object> parameters = null)
        {
            using (var connection = _dbService.GetConnection())
            using (var command = connection.CreateCommand())
            {
                command.CommandText = query;

                if (parameters != null)
                {
                    foreach (var param in parameters)
                    {
                        command.Parameters.AddWithValue(param.Key, param.Value);
                    }
                }

                return command.ExecuteNonQuery();
            }
        }

        public object ExecuteScalar(string query, Dictionary<string, object> parameters = null)
        {
            using (var connection = _dbService.GetConnection())
            using (var command = connection.CreateCommand())
            {
                command.CommandText = query;

                if (parameters != null)
                {
                    foreach (var param in parameters)
                    {
                        command.Parameters.AddWithValue(param.Key, param.Value);
                    }
                }

                return command.ExecuteScalar();
            }
        }

        public long Insert(string table, Dictionary<string, object> values)
        {
            var columns = string.Join(", ", values.Keys);
            var parameters = string.Join(", ", values.Keys.Select(k => "@" + k));
            var query = $"INSERT INTO {table} ({columns}) VALUES ({parameters}); SELECT last_insert_rowid();";

            return (long)ExecuteScalar(query, values);
        }

        public int Update(string table, Dictionary<string, object> values, string whereClause, Dictionary<string, object> whereParameters = null)
        {
            var setClause = string.Join(", ", values.Keys.Select(k => $"{k} = @{k}"));
            var query = $"UPDATE {table} SET {setClause} WHERE {whereClause}";

            var parameters = new Dictionary<string, object>(values);
            if (whereParameters != null)
            {
                foreach (var param in whereParameters)
                {
                    parameters.Add(param.Key, param.Value);
                }
            }

            return ExecuteNonQuery(query, parameters);
        }

        public int Delete(string table, string whereClause, Dictionary<string, object> parameters = null)
        {
            var query = $"DELETE FROM {table} WHERE {whereClause}";
            return ExecuteNonQuery(query, parameters);
        }
    }
} 