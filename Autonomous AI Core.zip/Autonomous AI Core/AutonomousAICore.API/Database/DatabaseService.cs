using System;
using System.IO;
using Microsoft.Data.Sqlite;

namespace AutonomousAICore.API.Database
{
    public class DatabaseService : IDisposable
    {
        private readonly SqliteConnection _connection;
        private readonly string _connectionString;

        public DatabaseService(string dbPath)
        {
            _connectionString = $"Data Source={dbPath};";
            _connection = new SqliteConnection(_connectionString);
            InitializeDatabase();
        }

        private void InitializeDatabase()
        {
            _connection.Open();
            using (var command = _connection.CreateCommand())
            {
                // Create Users table
                command.CommandText = @"
                    CREATE TABLE IF NOT EXISTS Users (
                        Id INTEGER PRIMARY KEY AUTOINCREMENT,
                        Name TEXT NOT NULL,
                        Email TEXT UNIQUE NOT NULL,
                        CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
                    );";
                command.ExecuteNonQuery();

                // Create Orders table
                command.CommandText = @"
                    CREATE TABLE IF NOT EXISTS Orders (
                        OrderId INTEGER PRIMARY KEY AUTOINCREMENT,
                        UserId INTEGER NOT NULL,
                        TotalAmount REAL NOT NULL,
                        CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (UserId) REFERENCES Users(Id)
                    );";
                command.ExecuteNonQuery();
            }
        }

        public SqliteConnection GetConnection()
        {
            if (_connection.State != System.Data.ConnectionState.Open)
            {
                _connection.Open();
            }
            return _connection;
        }

        public void Dispose()
        {
            _connection?.Dispose();
        }
    }
} 