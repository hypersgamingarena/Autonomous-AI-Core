using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using AutonomousAICore.API.Services;
using Microsoft.AspNetCore.Authorization;

namespace AutonomousAICore.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class RoslynController : ControllerBase
    {
        private readonly RoslynService _roslynService;
        private readonly ILogger<RoslynController> _logger;

        public RoslynController(RoslynService roslynService, ILogger<RoslynController> logger)
        {
            _roslynService = roslynService;
            _logger = logger;
        }

        [HttpPost("execute")]
        public async Task<IActionResult> ExecuteCode([FromBody] CodeExecutionRequest request)
        {
            try
            {
                var (success, result, error) = await _roslynService.ExecuteCodeAsync(request.Code);
                if (success)
                {
                    return Ok(new { result });
                }

                return BadRequest(new { error });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error executing code");
                return StatusCode(500, new { error = "An error occurred while executing the code" });
            }
        }

        [HttpPost("analyze")]
        public async Task<IActionResult> AnalyzeCode([FromBody] CodeAnalysisRequest request)
        {
            try
            {
                var (success, result, error) = await _roslynService.AnalyzeCodeAsync(request.Code);
                if (success)
                {
                    return Ok(new { analysis = result });
                }

                return BadRequest(new { error });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error analyzing code");
                return StatusCode(500, new { error = "An error occurred while analyzing the code" });
            }
        }

        [HttpPost("generate")]
        public async Task<IActionResult> GenerateCode([FromBody] CodeGenerationRequest request)
        {
            try
            {
                var (success, result, error) = await _roslynService.GenerateCodeAsync(request.Description);
                if (success)
                {
                    return Ok(new { code = result });
                }

                return BadRequest(new { error });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error generating code");
                return StatusCode(500, new { error = "An error occurred while generating the code" });
            }
        }
    }

    public class CodeExecutionRequest
    {
        public string Code { get; set; }
    }

    public class CodeAnalysisRequest
    {
        public string Code { get; set; }
    }

    public class CodeGenerationRequest
    {
        public string Description { get; set; }
    }
} 