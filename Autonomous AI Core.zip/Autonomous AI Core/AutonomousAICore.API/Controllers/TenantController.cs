using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AutonomousAICore.API.Tenant;

namespace AutonomousAICore.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TenantController : ControllerBase
    {
        private readonly TenantService _tenantService;

        public TenantController(TenantService tenantService)
        {
            _tenantService = tenantService;
        }

        [HttpPost]
        public async Task<ActionResult<Tenant>> CreateTenant([FromBody] CreateTenantRequest request)
        {
            try
            {
                var tenant = _tenantService.CreateTenant(request.Name, request.Identifier);
                return Ok(tenant);
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        [HttpGet("{identifier}")]
        public async Task<ActionResult<Tenant>> GetTenant(string identifier)
        {
            var tenant = _tenantService.GetTenant(identifier);
            if (tenant == null)
            {
                return NotFound();
            }
            return Ok(tenant);
        }

        [HttpGet]
        public async Task<ActionResult<List<Tenant>>> GetAllTenants()
        {
            var tenants = _tenantService.GetAllTenants();
            return Ok(tenants);
        }

        [HttpPut("{tenantId}/settings")]
        public async Task<IActionResult> UpdateTenantSettings(int tenantId, [FromBody] Dictionary<string, object> settings)
        {
            try
            {
                _tenantService.UpdateTenantSettings(tenantId, settings);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        [HttpDelete("{tenantId}")]
        public async Task<IActionResult> DeleteTenant(int tenantId)
        {
            try
            {
                _tenantService.DeleteTenant(tenantId);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }
    }

    public class CreateTenantRequest
    {
        public string Name { get; set; }
        public string Identifier { get; set; }
    }
} 