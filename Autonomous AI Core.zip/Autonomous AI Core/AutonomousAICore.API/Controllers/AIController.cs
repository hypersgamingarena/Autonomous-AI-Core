using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using AutonomousAICore.API.Services.Interfaces;
using AutonomousAICore.API.Models.AIModels;

namespace AutonomousAICore.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AIController : ControllerBase
    {
        private readonly IAIService _aiService;
        private readonly ILogger<AIController> _logger;

        public AIController(IAIService aiService, ILogger<AIController> logger)
        {
            _aiService = aiService;
            _logger = logger;
        }

        [HttpPost("models")]
        public async Task<ActionResult<TrainingModel>> CreateModel([FromBody] TrainingModel model)
        {
            try
            {
                var result = await _aiService.CreateModelAsync(model);
                return CreatedAtAction(nameof(GetModel), new { id = result.Id }, result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating model");
                return StatusCode(500, "An error occurred while creating the model");
            }
        }

        [HttpGet("models/{id}")]
        public async Task<ActionResult<TrainingModel>> GetModel(Guid id)
        {
            try
            {
                var model = await _aiService.GetModelAsync(id);
                if (model == null)
                    return NotFound();
                return Ok(model);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving model {ModelId}", id);
                return StatusCode(500, "An error occurred while retrieving the model");
            }
        }

        [HttpGet("models")]
        public async Task<ActionResult<System.Collections.Generic.IEnumerable<TrainingModel>>> GetAllModels()
        {
            try
            {
                var models = await _aiService.GetAllModelsAsync();
                return Ok(models);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving all models");
                return StatusCode(500, "An error occurred while retrieving models");
            }
        }

        [HttpPut("models/{id}")]
        public async Task<ActionResult<TrainingModel>> UpdateModel(Guid id, [FromBody] TrainingModel model)
        {
            try
            {
                if (id != model.Id)
                    return BadRequest("Model ID mismatch");

                var result = await _aiService.UpdateModelAsync(model);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating model {ModelId}", id);
                return StatusCode(500, "An error occurred while updating the model");
            }
        }

        [HttpDelete("models/{id}")]
        public async Task<ActionResult> DeleteModel(Guid id)
        {
            try
            {
                var result = await _aiService.DeleteModelAsync(id);
                if (!result)
                    return NotFound();
                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting model {ModelId}", id);
                return StatusCode(500, "An error occurred while deleting the model");
            }
        }

        [HttpPost("models/{id}/train")]
        public async Task<ActionResult> TrainModel(Guid id)
        {
            try
            {
                var result = await _aiService.TrainModelAsync(id);
                if (!result)
                    return NotFound();
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error training model {ModelId}", id);
                return StatusCode(500, "An error occurred while training the model");
            }
        }

        [HttpPost("models/{id}/evaluate")]
        public async Task<ActionResult> EvaluateModel(Guid id)
        {
            try
            {
                var result = await _aiService.EvaluateModelAsync(id);
                if (!result)
                    return NotFound();
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error evaluating model {ModelId}", id);
                return StatusCode(500, "An error occurred while evaluating the model");
            }
        }

        [HttpGet("models/{id}/metrics")]
        public async Task<ActionResult<System.Collections.Generic.Dictionary<string, double>>> GetModelMetrics(Guid id)
        {
            try
            {
                var metrics = await _aiService.GetModelMetricsAsync(id);
                return Ok(metrics);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting metrics for model {ModelId}", id);
                return StatusCode(500, "An error occurred while retrieving model metrics");
            }
        }

        [HttpPost("models/{id}/deploy")]
        public async Task<ActionResult> DeployModel(Guid id)
        {
            try
            {
                var result = await _aiService.DeployModelAsync(id);
                if (!result)
                    return NotFound();
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deploying model {ModelId}", id);
                return StatusCode(500, "An error occurred while deploying the model");
            }
        }

        [HttpPost("models/{id}/undeploy")]
        public async Task<ActionResult> UndeployModel(Guid id)
        {
            try
            {
                var result = await _aiService.UndeployModelAsync(id);
                if (!result)
                    return NotFound();
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error undeploying model {ModelId}", id);
                return StatusCode(500, "An error occurred while undeploying the model");
            }
        }

        [HttpPost("models/{id}/predict")]
        public async Task<ActionResult<object>> Predict(Guid id, [FromBody] object input)
        {
            try
            {
                var prediction = await _aiService.PredictAsync(id, input);
                return Ok(prediction);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error making prediction with model {ModelId}", id);
                return StatusCode(500, "An error occurred while making the prediction");
            }
        }

        [HttpGet("model-types")]
        public async Task<ActionResult<System.Collections.Generic.IEnumerable<string>>> GetAvailableModelTypes()
        {
            try
            {
                var types = await _aiService.GetAvailableModelTypesAsync();
                return Ok(types);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving available model types");
                return StatusCode(500, "An error occurred while retrieving model types");
            }
        }
    }
} 