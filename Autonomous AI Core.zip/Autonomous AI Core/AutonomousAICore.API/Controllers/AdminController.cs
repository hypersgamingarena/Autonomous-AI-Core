using Microsoft.AspNetCore.Mvc;
using AutonomousAICore.API.Admin;
using System;
using System.Collections.Generic;

namespace AutonomousAICore.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AdminController : ControllerBase
    {
        private readonly AdminConfigService _configService;
        private readonly LogService _logService;

        public AdminController(AdminConfigService configService, LogService logService)
        {
            _configService = configService;
            _logService = logService;
        }

        [HttpPost("config/{key}")]
        public IActionResult SaveConfig(string key, [FromBody] AdminConfig config)
        {
            try
            {
                _configService.SaveConfig(key, config);
                _logService.Log("Info", $"Configuration saved for key: {key}", "AdminController");
                return Ok(new { message = "Configuration saved successfully" });
            }
            catch (Exception ex)
            {
                _logService.Log("Error", $"Failed to save configuration: {ex.Message}", "AdminController", ex.ToString());
                return StatusCode(500, new { error = "Failed to save configuration", details = ex.Message });
            }
        }

        [HttpGet("config/{key}")]
        public IActionResult GetConfig(string key)
        {
            try
            {
                var config = _configService.LoadConfig(key);
                return Ok(config);
            }
            catch (Exception ex)
            {
                _logService.Log("Error", $"Failed to load configuration: {ex.Message}", "AdminController", ex.ToString());
                return StatusCode(500, new { error = "Failed to load configuration", details = ex.Message });
            }
        }

        [HttpGet("config")]
        public IActionResult GetAllConfigKeys()
        {
            try
            {
                var keys = _configService.GetAllConfigKeys();
                return Ok(keys);
            }
            catch (Exception ex)
            {
                _logService.Log("Error", $"Failed to get configuration keys: {ex.Message}", "AdminController", ex.ToString());
                return StatusCode(500, new { error = "Failed to get configuration keys", details = ex.Message });
            }
        }

        [HttpDelete("config/{key}")]
        public IActionResult DeleteConfig(string key)
        {
            try
            {
                _configService.DeleteConfig(key);
                _logService.Log("Info", $"Configuration deleted for key: {key}", "AdminController");
                return Ok(new { message = "Configuration deleted successfully" });
            }
            catch (Exception ex)
            {
                _logService.Log("Error", $"Failed to delete configuration: {ex.Message}", "AdminController", ex.ToString());
                return StatusCode(500, new { error = "Failed to delete configuration", details = ex.Message });
            }
        }

        [HttpGet("logs")]
        public IActionResult GetLogs([FromQuery] DateTime? startDate, [FromQuery] DateTime? endDate, [FromQuery] string level, [FromQuery] string source)
        {
            try
            {
                var logs = _logService.GetLogs(startDate, endDate, level, source);
                return Ok(logs);
            }
            catch (Exception ex)
            {
                _logService.Log("Error", $"Failed to get logs: {ex.Message}", "AdminController", ex.ToString());
                return StatusCode(500, new { error = "Failed to get logs", details = ex.Message });
            }
        }

        [HttpDelete("logs")]
        public IActionResult ClearLogs([FromQuery] DateTime? beforeDate)
        {
            try
            {
                _logService.ClearLogs(beforeDate);
                _logService.Log("Info", "Logs cleared successfully", "AdminController");
                return Ok(new { message = "Logs cleared successfully" });
            }
            catch (Exception ex)
            {
                _logService.Log("Error", $"Failed to clear logs: {ex.Message}", "AdminController", ex.ToString());
                return StatusCode(500, new { error = "Failed to clear logs", details = ex.Message });
            }
        }
    }
} 