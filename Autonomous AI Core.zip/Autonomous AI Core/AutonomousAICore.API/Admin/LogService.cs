using System;
using System.Collections.Generic;
using System.Data;
using AutonomousAICore.API.Database;

namespace AutonomousAICore.API.Admin
{
    public class LogEntry
    {
        public long Id { get; set; }
        public string Level { get; set; }
        public string Message { get; set; }
        public string Source { get; set; }
        public DateTime Timestamp { get; set; }
        public string Details { get; set; }
    }

    public class LogService
    {
        private readonly CrudService _crudService;
        private const string LOGS_TABLE = "SystemLogs";

        public LogService(CrudService crudService)
        {
            _crudService = crudService;
            InitializeLogsTable();
        }

        private void InitializeLogsTable()
        {
            var query = $@"
                CREATE TABLE IF NOT EXISTS {LOGS_TABLE} (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Level TEXT NOT NULL,
                    Message TEXT NOT NULL,
                    Source TEXT NOT NULL,
                    Timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    Details TEXT
                );";

            _crudService.ExecuteNonQuery(query);
        }

        public void Log(string level, string message, string source, string details = null)
        {
            var values = new Dictionary<string, object>
            {
                { "Level", level },
                { "Message", message },
                { "Source", source },
                { "Details", details }
            };

            _crudService.Insert(LOGS_TABLE, values);
        }

        public List<LogEntry> GetLogs(DateTime? startDate = null, DateTime? endDate = null, string level = null, string source = null)
        {
            var conditions = new List<string>();
            var parameters = new Dictionary<string, object>();

            if (startDate.HasValue)
            {
                conditions.Add("Timestamp >= @startDate");
                parameters.Add("@startDate", startDate.Value);
            }

            if (endDate.HasValue)
            {
                conditions.Add("Timestamp <= @endDate");
                parameters.Add("@endDate", endDate.Value);
            }

            if (!string.IsNullOrEmpty(level))
            {
                conditions.Add("Level = @level");
                parameters.Add("@level", level);
            }

            if (!string.IsNullOrEmpty(source))
            {
                conditions.Add("Source = @source");
                parameters.Add("@source", source);
            }

            var whereClause = conditions.Count > 0 ? "WHERE " + string.Join(" AND ", conditions) : "";
            var query = $"SELECT * FROM {LOGS_TABLE} {whereClause} ORDER BY Timestamp DESC;";

            var result = _crudService.ExecuteQuery(query, parameters);
            var logs = new List<LogEntry>();

            foreach (DataRow row in result.Rows)
            {
                logs.Add(new LogEntry
                {
                    Id = Convert.ToInt64(row["Id"]),
                    Level = row["Level"].ToString(),
                    Message = row["Message"].ToString(),
                    Source = row["Source"].ToString(),
                    Timestamp = Convert.ToDateTime(row["Timestamp"]),
                    Details = row["Details"]?.ToString()
                });
            }

            return logs;
        }

        public void ClearLogs(DateTime? beforeDate = null)
        {
            var query = $"DELETE FROM {LOGS_TABLE}";
            var parameters = new Dictionary<string, object>();

            if (beforeDate.HasValue)
            {
                query += " WHERE Timestamp < @beforeDate";
                parameters.Add("@beforeDate", beforeDate.Value);
            }

            _crudService.ExecuteNonQuery(query, parameters);
        }
    }
} 