using System;
using System.Collections.Generic;
using System.Text.Json;
using System.IO;
using AutonomousAICore.API.Database;

namespace AutonomousAICore.API.Admin
{
    public class AdminConfig
    {
        public string Theme { get; set; }
        public Dictionary<string, object> Settings { get; set; }
        public DateTime LastModified { get; set; }
    }

    public class AdminConfigService
    {
        private readonly CrudService _crudService;
        private const string CONFIG_TABLE = "AdminConfigs";

        public AdminConfigService(CrudService crudService)
        {
            _crudService = crudService;
            InitializeConfigTable();
        }

        private void InitializeConfigTable()
        {
            var query = $@"
                CREATE TABLE IF NOT EXISTS {CONFIG_TABLE} (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Key TEXT UNIQUE NOT NULL,
                    Value TEXT NOT NULL,
                    LastModified DATETIME DEFAULT CURRENT_TIMESTAMP
                );";

            _crudService.ExecuteNonQuery(query);
        }

        public void SaveConfig(string key, AdminConfig config)
        {
            config.LastModified = DateTime.UtcNow;
            var jsonValue = JsonSerializer.Serialize(config);

            var parameters = new Dictionary<string, object>
            {
                { "@key", key },
                { "@value", jsonValue }
            };

            var query = $@"
                INSERT INTO {CONFIG_TABLE} (Key, Value)
                VALUES (@key, @value)
                ON CONFLICT(Key) DO UPDATE SET
                    Value = @value,
                    LastModified = CURRENT_TIMESTAMP;";

            _crudService.ExecuteNonQuery(query, parameters);
        }

        public AdminConfig LoadConfig(string key)
        {
            var parameters = new Dictionary<string, object>
            {
                { "@key", key }
            };

            var query = $"SELECT Value FROM {CONFIG_TABLE} WHERE Key = @key;";
            var result = _crudService.ExecuteQuery(query, parameters);

            if (result.Rows.Count == 0)
            {
                return new AdminConfig
                {
                    Theme = "default",
                    Settings = new Dictionary<string, object>(),
                    LastModified = DateTime.UtcNow
                };
            }

            var jsonValue = result.Rows[0]["Value"].ToString();
            return JsonSerializer.Deserialize<AdminConfig>(jsonValue);
        }

        public void DeleteConfig(string key)
        {
            var parameters = new Dictionary<string, object>
            {
                { "@key", key }
            };

            var query = $"DELETE FROM {CONFIG_TABLE} WHERE Key = @key;";
            _crudService.ExecuteNonQuery(query, parameters);
        }

        public List<string> GetAllConfigKeys()
        {
            var query = $"SELECT Key FROM {CONFIG_TABLE};";
            var result = _crudService.ExecuteQuery(query);

            var keys = new List<string>();
            foreach (DataRow row in result.Rows)
            {
                keys.Add(row["Key"].ToString());
            }

            return keys;
        }
    }
} 