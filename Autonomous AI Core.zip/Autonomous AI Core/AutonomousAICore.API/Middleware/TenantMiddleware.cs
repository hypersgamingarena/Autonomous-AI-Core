using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using AutonomousAICore.API.Tenant;

namespace AutonomousAICore.API.Middleware
{
    public class TenantMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly TenantService _tenantService;

        public TenantMiddleware(RequestDelegate next, TenantService tenantService)
        {
            _next = next;
            _tenantService = tenantService;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            // Get tenant identifier from header or query string
            string tenantIdentifier = context.Request.Headers["X-Tenant-Identifier"].ToString();
            if (string.IsNullOrEmpty(tenantIdentifier))
            {
                tenantIdentifier = context.Request.Query["tenant"].ToString();
            }

            if (!string.IsNullOrEmpty(tenantIdentifier))
            {
                var tenant = _tenantService.GetTenant(tenantIdentifier);
                if (tenant != null)
                {
                    // Store tenant in HttpContext items for use in controllers
                    context.Items["CurrentTenant"] = tenant;
                }
            }

            await _next(context);
        }
    }

    // Extension method to make it easier to add the middleware
    public static class TenantMiddlewareExtensions
    {
        public static IApplicationBuilder UseTenantMiddleware(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<TenantMiddleware>();
        }
    }
} 