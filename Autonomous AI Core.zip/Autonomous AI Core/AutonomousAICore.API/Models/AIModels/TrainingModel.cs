using System;
using System.Collections.Generic;
using AutonomousAICore.API.Models.Base;

namespace AutonomousAICore.API.Models.AIModels
{
    public class TrainingModel : BaseEntity
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string ModelType { get; set; }
        public string Version { get; set; }
        public Dictionary<string, object> Parameters { get; set; }
        public string TrainingDataPath { get; set; }
        public DateTime? LastTrained { get; set; }
        public string Status { get; set; }
        public double Accuracy { get; set; }
        public List<string> Tags { get; set; }
        public bool IsActive { get; set; }
    }
} 