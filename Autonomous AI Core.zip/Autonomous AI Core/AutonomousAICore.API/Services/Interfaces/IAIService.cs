using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutonomousAICore.API.Models.AIModels;

namespace AutonomousAICore.API.Services.Interfaces
{
    public interface IAIService
    {
        Task<TrainingModel> CreateModelAsync(TrainingModel model);
        Task<TrainingModel> GetModelAsync(Guid id);
        Task<IEnumerable<TrainingModel>> GetAllModelsAsync();
        Task<TrainingModel> UpdateModelAsync(TrainingModel model);
        Task<bool> DeleteModelAsync(Guid id);
        Task<bool> TrainModelAsync(Guid id);
        Task<bool> EvaluateModelAsync(Guid id);
        Task<Dictionary<string, double>> GetModelMetricsAsync(Guid id);
        Task<bool> DeployModelAsync(Guid id);
        Task<bool> UndeployModelAsync(Guid id);
        Task<object> PredictAsync(Guid modelId, object input);
        Task<bool> ValidateModelAsync(Guid id);
        Task<bool> ExportModelAsync(Guid id, string format);
        Task<bool> ImportModelAsync(string path, string format);
        Task<IEnumerable<string>> GetAvailableModelTypesAsync();
        Task<Dictionary<string, object>> GetModelParametersAsync(Guid id);
        Task<bool> UpdateModelParametersAsync(Guid id, Dictionary<string, object> parameters);
    }
} 