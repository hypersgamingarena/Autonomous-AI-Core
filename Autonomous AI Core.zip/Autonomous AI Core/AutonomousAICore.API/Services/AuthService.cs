using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using AutonomousAICore.API.Models.Auth;
using System.Security.Cryptography;

namespace AutonomousAICore.API.Services
{
    public class AuthService
    {
        private readonly IConfiguration _configuration;
        private readonly ApplicationDbContext _context;

        public AuthService(IConfiguration configuration, ApplicationDbContext context)
        {
            _configuration = configuration;
            _context = context;
        }

        public async Task<(bool success, string token)> LoginAsync(LoginModel model)
        {
            try
            {
                // In a real application, you would validate against a database
                // This is a simplified example
                if (model.Email == "admin@example.com" && model.Password == "Admin123!")
                {
                    var token = GenerateJwtToken(model.Email, "Admin");
                    return (true, token);
                }

                return (false, null);
            }
            catch (Exception ex)
            {
                // Log the exception
                return (false, null);
            }
        }

        public async Task<bool> RegisterAsync(RegisterModel model)
        {
            try
            {
                // In a real application, you would:
                // 1. Check if user already exists
                // 2. Hash the password
                // 3. Save to database
                return true;
            }
            catch (Exception ex)
            {
                // Log the exception
                return false;
            }
        }

        private string GenerateJwtToken(string email, string role)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Security:JwtKey"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
                new Claim(ClaimTypes.Email, email),
                new Claim(ClaimTypes.Role, role),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
            };

            var token = new JwtSecurityToken(
                issuer: _configuration["Security:JwtIssuer"],
                audience: _configuration["Security:JwtAudience"],
                claims: claims,
                expires: DateTime.Now.AddDays(Convert.ToDouble(_configuration["Security:JwtExpiryInDays"])),
                signingCredentials: credentials
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        private string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(hashedBytes);
            }
        }
    }
} 