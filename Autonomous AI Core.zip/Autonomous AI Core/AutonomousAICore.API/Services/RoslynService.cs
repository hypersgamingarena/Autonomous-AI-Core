using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Scripting;
using Microsoft.CodeAnalysis.Scripting;
using Microsoft.Extensions.Logging;

namespace AutonomousAICore.API.Services
{
    public class RoslynService
    {
        private readonly ILogger<RoslynService> _logger;
        private readonly ScriptOptions _scriptOptions;

        public RoslynService(ILogger<RoslynService> logger)
        {
            _logger = logger;
            _scriptOptions = ScriptOptions.Default
                .AddReferences(typeof(System.Console).Assembly)
                .AddReferences(typeof(System.Linq.Enumerable).Assembly)
                .AddImports("System")
                .AddImports("System.Linq")
                .AddImports("System.Collections.Generic");
        }

        public async Task<(bool success, object result, string error)> ExecuteCodeAsync(string code)
        {
            try
            {
                var script = CSharpScript.Create(code, _scriptOptions);
                var compilation = script.GetCompilation();
                var diagnostics = compilation.GetDiagnostics();

                if (diagnostics.Any(d => d.Severity == DiagnosticSeverity.Error))
                {
                    var errors = string.Join("\n", diagnostics.Select(d => d.GetMessage()));
                    return (false, null, errors);
                }

                var result = await script.RunAsync();
                return (true, result.ReturnValue, null);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error executing code");
                return (false, null, ex.Message);
            }
        }

        public async Task<(bool success, string result, string error)> AnalyzeCodeAsync(string code)
        {
            try
            {
                var tree = CSharpSyntaxTree.ParseText(code);
                var compilation = CSharpCompilation.Create("DynamicCode")
                    .AddReferences(MetadataReference.CreateFromFile(typeof(object).Assembly.Location))
                    .AddSyntaxTrees(tree);

                var diagnostics = compilation.GetDiagnostics();
                var analysis = new List<string>();

                foreach (var diagnostic in diagnostics)
                {
                    analysis.Add($"{diagnostic.Severity}: {diagnostic.GetMessage()}");
                }

                // Additional analysis
                var root = await tree.GetRootAsync();
                var methods = root.DescendantNodes().OfType<Microsoft.CodeAnalysis.CSharp.Syntax.MethodDeclarationSyntax>();
                var classes = root.DescendantNodes().OfType<Microsoft.CodeAnalysis.CSharp.Syntax.ClassDeclarationSyntax>();

                analysis.Add($"\nFound {methods.Count()} methods and {classes.Count()} classes");

                return (true, string.Join("\n", analysis), null);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error analyzing code");
                return (false, null, ex.Message);
            }
        }

        public async Task<(bool success, string result, string error)> GenerateCodeAsync(string description)
        {
            try
            {
                // This is a simplified example. In a real application, you would use
                // a more sophisticated code generation approach
                var code = $@"
using System;
using System.Linq;
using System.Collections.Generic;

public class GeneratedClass
{{
    public void ProcessData()
    {{
        // Generated code based on description: {description}
        Console.WriteLine(""Processing data..."");
    }}
}}";

                return (true, code, null);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error generating code");
                return (false, null, ex.Message);
            }
        }
    }
} 