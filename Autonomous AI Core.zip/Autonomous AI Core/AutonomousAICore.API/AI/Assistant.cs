using System;
using System.Threading.Tasks;
using Microsoft.ML;
using Microsoft.ML.Data;

namespace AutonomousAICore.API.AI
{
    public class AssistantInput
    {
        [LoadColumn(0)]
        public string Query { get; set; }

        [LoadColumn(1)]
        public string Context { get; set; }
    }

    public class AssistantOutput
    {
        [ColumnName("PredictedLabel")]
        public string Response { get; set; }

        public float[] Score { get; set; }
    }

    public class Assistant
    {
        private readonly MLContext _mlContext;
        private readonly string _modelPath;
        private ITransformer _model;
        private PredictionEngine<AssistantInput, AssistantOutput> _predictionEngine;

        public Assistant(string modelPath)
        {
            _mlContext = new MLContext(seed: 1);
            _modelPath = modelPath;
            LoadOrTrainModel();
        }

        private void LoadOrTrainModel()
        {
            if (System.IO.File.Exists(_modelPath))
            {
                LoadModel();
            }
            else
            {
                TrainModel();
            }
        }

        private void LoadModel()
        {
            try
            {
                using (var stream = System.IO.File.OpenRead(_modelPath))
                {
                    _model = _mlContext.Model.Load(stream, out var _);
                }
                _predictionEngine = _mlContext.Model.CreatePredictionEngine<AssistantInput, AssistantOutput>(_model);
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to load assistant model: {ex.Message}", ex);
            }
        }

        private void TrainModel()
        {
            try
            {
                // Create a simple pipeline for text classification
                var pipeline = _mlContext.Transforms.Text
                    .FeaturizeText("Features", "Query")
                    .Append(_mlContext.Transforms.Concatenate("Features", "Features", "Context"))
                    .Append(_mlContext.Transforms.NormalizeMinMax("Features"))
                    .Append(_mlContext.MulticlassClassification.Trainers.SdcaNonCalibrated())
                    .Append(_mlContext.Transforms.Conversion.MapKeyToValue("PredictedLabel"));

                // Create some sample data for training
                var sampleData = new[]
                {
                    new AssistantInput { Query = "What is the weather?", Context = "weather", Response = "I can't check the weather offline." },
                    new AssistantInput { Query = "Help me with a task", Context = "general", Response = "I'm here to help. What do you need?" },
                    // Add more training examples as needed
                };

                var trainingData = _mlContext.Data.LoadFromEnumerable(sampleData);
                _model = pipeline.Fit(trainingData);

                // Save the model
                using (var stream = System.IO.File.Create(_modelPath))
                {
                    _mlContext.Model.Save(_model, trainingData.Schema, stream);
                }

                _predictionEngine = _mlContext.Model.CreatePredictionEngine<AssistantInput, AssistantOutput>(_model);
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to train assistant model: {ex.Message}", ex);
            }
        }

        public string ProcessQuery(string query, string context = "general")
        {
            try
            {
                var input = new AssistantInput { Query = query, Context = context };
                var prediction = _predictionEngine.Predict(input);
                return prediction.Response;
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to process query: {ex.Message}", ex);
            }
        }

        public async Task<string> ProcessQueryAsync(string query, string context = "general")
        {
            return await Task.Run(() => ProcessQuery(query, context));
        }
    }
} 