using System;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;

namespace AutonomousAICore.API.AI
{
    public class DataDownloader
    {
        private readonly HttpClient _httpClient;
        private readonly string _localDataPath;

        public DataDownloader(string localDataPath)
        {
            _httpClient = new HttpClient();
            _localDataPath = localDataPath;
            Directory.CreateDirectory(_localDataPath);
        }

        public async Task<string> DownloadDataAsync(string url, string fileName)
        {
            try
            {
                var response = await _httpClient.GetAsync(url);
                response.EnsureSuccessStatusCode();

                var filePath = Path.Combine(_localDataPath, fileName);
                using (var fileStream = File.Create(filePath))
                {
                    await response.Content.CopyToAsync(fileStream);
                }

                return filePath;
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to download data: {ex.Message}", ex);
            }
        }

        public bool IsDataAvailable(string fileName)
        {
            var filePath = Path.Combine(_localDataPath, fileName);
            return File.Exists(filePath);
        }

        public string GetLocalDataPath(string fileName)
        {
            return Path.Combine(_localDataPath, fileName);
        }
    }
} 