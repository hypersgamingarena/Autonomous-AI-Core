using System;
using System.IO;
using Microsoft.ML;
using Microsoft.ML.Data;

namespace AutonomousAICore.API.AI
{
    public class ModelTrainer
    {
        private readonly MLContext _mlContext;
        private readonly string _modelPath;

        public ModelTrainer(string modelPath)
        {
            _mlContext = new MLContext(seed: 1);
            _modelPath = modelPath;
            Directory.CreateDirectory(Path.GetDirectoryName(_modelPath));
        }

        public ITransformer TrainModel<TInput>(string dataPath, string labelColumnName, string[] featureColumns)
            where TInput : class
        {
            try
            {
                // Load data
                var data = _mlContext.Data.LoadFromTextFile<TInput>(dataPath, hasHeader: true, separatorChar: ',');

                // Create pipeline
                var pipeline = _mlContext.Transforms.Concatenate("Features", featureColumns)
                    .Append(_mlContext.Transforms.NormalizeMinMax("Features"))
                    .Append(_mlContext.Transforms.Conversion.MapValueToKey("Label", labelColumnName))
                    .Append(_mlContext.MulticlassClassification.Trainers.SdcaNonCalibrated())
                    .Append(_mlContext.Transforms.Conversion.MapKeyToValue("PredictedLabel"));

                // Train model
                var model = pipeline.Fit(data);

                // Save model
                using (var fileStream = File.Create(_modelPath))
                {
                    _mlContext.Model.Save(model, data.Schema, fileStream);
                }

                return model;
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to train model: {ex.Message}", ex);
            }
        }

        public ITransformer LoadModel()
        {
            try
            {
                if (!File.Exists(_modelPath))
                {
                    throw new FileNotFoundException("Model file not found", _modelPath);
                }

                using (var fileStream = File.OpenRead(_modelPath))
                {
                    return _mlContext.Model.Load(fileStream, out var _);
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to load model: {ex.Message}", ex);
            }
        }

        public bool IsModelAvailable()
        {
            return File.Exists(_modelPath);
        }
    }
} 