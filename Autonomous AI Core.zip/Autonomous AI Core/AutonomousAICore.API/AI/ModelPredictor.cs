using System;
using Microsoft.ML;

namespace AutonomousAICore.API.AI
{
    public class ModelPredictor
    {
        private readonly MLContext _mlContext;
        private readonly ITransformer _model;

        public ModelPredictor(ITransformer model)
        {
            _mlContext = new MLContext(seed: 1);
            _model = model ?? throw new ArgumentNullException(nameof(model));
        }

        public TOutput Predict<TInput, TOutput>(TInput input)
            where TInput : class
            where TOutput : class, new()
        {
            try
            {
                var predictionEngine = _mlContext.Model.CreatePredictionEngine<TInput, TOutput>(_model);
                return predictionEngine.Predict(input);
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to make prediction: {ex.Message}", ex);
            }
        }

        public TOutput[] PredictBatch<TInput, TOutput>(TInput[] inputs)
            where TInput : class
            where TOutput : class, new()
        {
            try
            {
                var predictionEngine = _mlContext.Model.CreatePredictionEngine<TInput, TOutput>(_model);
                var predictions = new TOutput[inputs.Length];

                for (int i = 0; i < inputs.Length; i++)
                {
                    predictions[i] = predictionEngine.Predict(inputs[i]);
                }

                return predictions;
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to make batch predictions: {ex.Message}", ex);
            }
        }
    }
} 