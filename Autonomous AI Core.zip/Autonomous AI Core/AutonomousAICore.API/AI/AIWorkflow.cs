using System;
using System.Threading.Tasks;
using Microsoft.ML;

namespace AutonomousAICore.API.AI
{
    public class AIWorkflow
    {
        private readonly DataDownloader _dataDownloader;
        private readonly ModelTrainer _modelTrainer;
        private ModelPredictor _modelPredictor;

        public AIWorkflow(string localDataPath, string modelPath)
        {
            _dataDownloader = new DataDownloader(localDataPath);
            _modelTrainer = new ModelTrainer(modelPath);
        }

        public async Task InitializeAsync(string dataUrl, string fileName)
        {
            try
            {
                // Download data if not available
                if (!_dataDownloader.IsDataAvailable(fileName))
                {
                    await _dataDownloader.DownloadDataAsync(dataUrl, fileName);
                }

                // Train or load model
                if (!_modelTrainer.IsModelAvailable())
                {
                    // This is a placeholder - you'll need to define your data model and features
                    var model = _modelTrainer.TrainModel<object>(
                        _dataDownloader.GetLocalDataPath(fileName),
                        "Label",
                        new[] { "Feature1", "Feature2" }
                    );
                    _modelPredictor = new ModelPredictor(model);
                }
                else
                {
                    var model = _modelTrainer.LoadModel();
                    _modelPredictor = new ModelPredictor(model);
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to initialize AI workflow: {ex.Message}", ex);
            }
        }

        public TOutput MakePrediction<TInput, TOutput>(TInput input)
            where TInput : class
            where TOutput : class, new()
        {
            if (_modelPredictor == null)
            {
                throw new InvalidOperationException("AI workflow not initialized. Call InitializeAsync first.");
            }

            return _modelPredictor.Predict<TInput, TOutput>(input);
        }

        public TOutput[] MakeBatchPredictions<TInput, TOutput>(TInput[] inputs)
            where TInput : class
            where TOutput : class, new()
        {
            if (_modelPredictor == null)
            {
                throw new InvalidOperationException("AI workflow not initialized. Call InitializeAsync first.");
            }

            return _modelPredictor.PredictBatch<TInput, TOutput>(inputs);
        }
    }
} 